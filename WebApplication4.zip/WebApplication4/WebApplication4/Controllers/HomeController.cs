﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using QRCoder;
using WebApplication4.Models;

namespace WebApplication4.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            //return View();

            QRCodeGenerator qrGenerator = new QRCodeGenerator();

            var prod = new Conteudo
            {
                Protocolo = 1,
                Placa_Veiculo = "HGO 3030",
                Placa_Carreta = "HMY 4455",
                Fluxo = " Fluxo 1",
                Transportadora = "Michelin",
                Motorista = "Abner Silva",
                CPF = "21512144458",
                CNH = "123456789123456",
                RG = "3422114111548",
                Emissor = "UF",
                Tipo = "DOC",
                Documento_Fiscal = "Doc Fiscal 123",
                Peso_Origem = "12,00",
                Documentto_Transporte = "Doc Trans 124",
                Item_Material = "Agua"

            };

            var json = JsonConvert.SerializeObject(prod);

            QRCodeData qrCodeData = qrGenerator.CreateQrCode(json, QRCodeGenerator.ECCLevel.Q);
            QRCode qrCode = new QRCode(qrCodeData);
            Bitmap qrCodeImage = qrCode.GetGraphic(20);

            var bitmapBytes = BitmapToBytes(qrCodeImage); //Convert bitmap into a byte array
            return File(bitmapBytes, "image/jpeg"); //Return as file result
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }




        private static byte[] BitmapToBytes(Bitmap img)
        {
            using (MemoryStream stream = new MemoryStream())
            {
                img.Save(stream, System.Drawing.Imaging.ImageFormat.Png);
                return stream.ToArray();
            }
        }

    }
}
