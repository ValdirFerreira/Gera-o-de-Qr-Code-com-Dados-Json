﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication4.Models
{
    public class Conteudo
    {
        
        public int Protocolo { get; set; }
        public string Placa_Veiculo { get; set; }
        public string Placa_Carreta { get; set; }
        public string Fluxo { get; set; }
        public string Transportadora { get; set; }
        public string Motorista { get; set; }
        public string CPF { get; set; }
        public string CNH { get; set; }
        public string RG { get; set; }
        public string Emissor { get; set; }
        public string Tipo { get; set; }
        public string Item_Material { get; set; }
        public string Documento_Fiscal { get; set; }
        public string Peso_Origem { get; set; }
        public string Documentto_Transporte { get; set; }

    }
}
